export const setcurrentuser=(data)=>{
    return{
        type:"FETCH_CURRENT_USER",
        payload:data,
    };
};